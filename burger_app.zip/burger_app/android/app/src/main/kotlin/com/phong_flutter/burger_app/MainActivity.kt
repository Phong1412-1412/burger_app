package com.phong_flutter.burger_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
