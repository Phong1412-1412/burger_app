import 'package:burger_app/Cart/Cart_Controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';

class CartTotal extends StatefulWidget {
  @override
  _CartTotalState createState() => _CartTotalState();
}

class _CartTotalState extends State<CartTotal> {
  final CartController controller = Get.find();

  @override
  void initState() {
    super.initState();
  }

  Widget build(BuildContext context) {
    // TODO: implement build
    return Obx(() => Container(
          child: FlatButton(
            onPressed: () {
              Get.snackbar("Thông báo", "Bạn đã đặt hàng thành côgn",
                  snackPosition: SnackPosition.TOP,
                  duration: Duration(seconds: 1),
                  colorText: Colors.white,
                  backgroundColor: Colors.redAccent,

              );
            },
            padding: EdgeInsets.all(15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            color: Colors.blue.shade400,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text('total: ',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
                controller.products.length != 0
                    ? Text('${controller.total} VND',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white))
                    : Text(""),
              ],
            ),
          ),
        ));
  }
}
