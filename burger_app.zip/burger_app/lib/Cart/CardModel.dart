class Cart {
  int? cardID;
  String? foodName;
  String? foodImg;
  int? foodPrice;

  Cart({this.cardID, this.foodName, this.foodImg, this.foodPrice});

  Cart.fromJson(Map<String, dynamic> json) {
    cardID = json['Card_ID'];
    foodName = json['Food_Name'];
    foodImg = json['Food_Img'];
    foodPrice = json['Food_Price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Card_ID'] = this.cardID;
    data['Food_Name'] = this.foodName;
    data['Food_Img'] = this.foodImg;
    data['Food_Price'] = this.foodPrice;
    return data;
  }
}
