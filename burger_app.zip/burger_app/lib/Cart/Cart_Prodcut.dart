import 'package:burger_app/Cart/CardModel.dart';
import 'package:burger_app/Cart/Cart_Controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../Food/FoodModel.dart';

final CartController controller = Get.find();
class CartProdcut extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Obx(
          () => SizedBox(
        height: 600,
        child: ListView.builder(
          itemCount: controller.products.length,
          itemBuilder: (context, index) {
            return CartProductCard(
              controller: controller,
              food: controller.products.keys.toList()[index],
              quantity: controller.products.values.toList()[index],
              index: index,
            );
          },
        ),
      ),
    );
  }
}
class CartProductCard extends StatelessWidget {
  final CartController controller;
  final Food food;
  final quantity;
  final int index;

  const CartProductCard({Key? key, required this.controller, required this.food, this.quantity, required this.index}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 5, vertical: 10),
      child: Container(
        //color: Colors.green.withOpacity(0.5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage:controller.products.length!=0? AssetImage('${food.foodImg}'): AssetImage("images/avata01.jpg"),
            ),
            SizedBox(width: 20,),
            controller.products.length!=0?
            Expanded(child:Text('${food.foodName}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),))
            :
            Expanded(child:Text('Non Product', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),)),

            IconButton(onPressed: (){controller.removeProdcut(food);}, icon: Icon(Icons.remove_circle)),
            controller.products.length!=0?
            Text('${quantity}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),)
            :
            Text('0', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),),
            IconButton(onPressed: (){controller.addProduct(food);}, icon: Icon(Icons.add_circle)),
          ],
        ),
      ),
    );
  }
}