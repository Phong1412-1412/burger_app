import 'package:get/get.dart';
import '../Food/FoodModel.dart';




class CartController extends GetxController{
  //add a dict to store the products in the cart.
  var products = {}.obs;
  void addProduct(Food food) {
    if(products.containsKey(food)) {
      products[food] += 1;
    }else {
      products[food] = 1;
    }
    Get.snackbar("Product added", "You have added the ${food.foodName} to the cart",
    snackPosition: SnackPosition.BOTTOM,
    duration: Duration(seconds: 1),
    );

  }

  void removeProdcut(Food food) {
    if(products.containsKey(food) && products[food]==1) {
      products.removeWhere((key, value) => key == food);
    }
    else {
      products[food] -=1;
    }
  }

  get productSubtotal => products.entries.map((Food) => Food.key.foodPrice * Food.value).toList();

  get total => products.entries.map((Food) => Food.key.foodPrice * Food.value).toList()
  .reduce((value, element) => value+element).toString();
}