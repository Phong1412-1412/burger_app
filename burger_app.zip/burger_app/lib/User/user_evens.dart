import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import 'package:burger_app/User/UserModel.dart';
abstract class UserEvent extends  Equatable {

  @override
  List<Object> get props => [];
}

class UserGetAllEvent extends UserEvent {

}

//lấy 1 user
class UserGetEvent extends UserEvent {
  final int nguoidungid;

  UserGetEvent(this.nguoidungid);
}
//cập nhật và sửa đổi
class UserUpdateCreateEvent extends UserEvent {
  final userModel item;
  final bool isEdit;//true cập nhật, fales thêm mới

  UserUpdateCreateEvent(this.item, this.isEdit);
}

class UserDeleteEvent extends UserEvent {

  final userModel item;

  UserDeleteEvent(this.item);

}

class UserNoThingEvent extends UserEvent {

}


