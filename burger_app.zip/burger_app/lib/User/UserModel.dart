class userModel {
  int? nguoiDungID;
  String? nguoiDungName;
  int? nguoiDungPassWord;
  String? nguoiDungEmail;
  int? nguoiDungPoint;
  String? nguoiDungRank;

  userModel(
      {this.nguoiDungID,
        this.nguoiDungName,
        this.nguoiDungPassWord,
        this.nguoiDungEmail,
        this.nguoiDungPoint,
        this.nguoiDungRank});

  userModel.fromJson(Map<String, dynamic> json) {
    nguoiDungID = json['NguoiDung_ID'];
    nguoiDungName = json['NguoiDung_Name'];
    nguoiDungPassWord = json['NguoiDung_PassWord'];
    nguoiDungEmail = json['NguoiDung_Email'];
    nguoiDungPoint = json['NguoiDung_Point'];
    nguoiDungRank = json['NguoiDung_Rank'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['NguoiDung_ID'] = this.nguoiDungID;
    data['NguoiDung_Name'] = this.nguoiDungName;
    data['NguoiDung_PassWord'] = this.nguoiDungPassWord;
    data['NguoiDung_Email'] = this.nguoiDungEmail;
    data['NguoiDung_Point'] = this.nguoiDungPoint;
    data['NguoiDung_Rank'] = this.nguoiDungRank;
    return data;
  }
}
