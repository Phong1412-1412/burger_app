import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import 'package:burger_app/User/UserModel.dart';

abstract class UserState extends Equatable {
  @override
  List<Object> get props =>[];

  @override
  String toString() {
    return "SinhVienStata{}";
  }
}
// Khởi tạo
class UserInitinalState extends UserState {
  @override
  String toString() {
    return "UserInitalState{}";
  }
}

class UserSuccess extends UserState {
  final List<userModel> lstuser;

  UserSuccess(this.lstuser);

}

class UserFailureState extends UserState {
  final String thongBao;

  UserFailureState(this.thongBao);
}

class UserUpdateState extends UserState {
  final userModel item;
  final int status;

  UserUpdateState(this.item, this.status);

}