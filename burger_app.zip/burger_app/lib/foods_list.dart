import 'package:burger_app/food_detail.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Cart/Cart_Controller.dart';
import 'bugger_fage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'Food/FoodModel.dart';
import 'data_sources/api_services.dart';
import 'package:get/get.dart';



class NetworkRequest {
  static String IP = url;
  static String Url = "";
  static String GetFoods = IP + Url;

  GetAPI(String API) {
      Url = API;
      GetFoods = IP+Url;
  }

  static List<Food> parseFood(String responseBody) {
    var list = json.decode(responseBody) as List<dynamic>;
    List<Food> Foods = list.map((model) => Food.fromJson(model)).toList();
    return Foods;
  }

  static Future<List<Food>> fetchFood({int page = 1}) async {
    final response = await http.get(Uri.parse(GetFoods));
    if (response.statusCode == 200) {
      return compute(parseFood, response.body);
    } else if (response.statusCode == 404) {
      throw Exception("Not Found");
    } else {
      throw Exception("Can\'t get category");
    }
  }
}

class FoodsList extends StatefulWidget {
  final int row ;
  final String adressAPI;
  FoodsList(this.row, this.adressAPI);
  @override
  _FoodsListState createState() => _FoodsListState(adressApi: adressAPI);
}

class _FoodsListState extends State<FoodsList>  {
  final cartController = Get.put(CartController());
   String adressApi;
  _FoodsListState({Key?key, required this.adressApi});
  List<Food> foodData = List.empty();
  void initState() {
    super.initState();
    NetworkRequest().GetAPI(adressApi);
    NetworkRequest.fetchFood().then((dataFromServer) {
      setState(() {
        foodData = dataFromServer;
      });
    });
  }

  @override
  // Widget build(BuildContext context) {
  //   // TODO: implement build
  //   return SliverGrid(
  //       delegate: SliverChildBuilderDelegate(
  //           (context, index) {
  //             return Container(
  //
  //             );
  //           },
  //         childCount: foodData.length,
  //       ),
  //       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
  //         mainAxisSpacing: 15,
  //         crossAxisSpacing: 15,
  //         crossAxisCount: 4
  //       ),
  //     );
  // }

  Widget build(BuildContext context) {
    int currentSelectedItems = 0;
    int numCount = foodData.length;
    List<String> listProduct = [];
    // TODO: implement build
    return SliverToBoxAdapter(
      child: Container(
        height: widget.row==1? 240:370,
        margin: EdgeInsets.only(top: 10),
        child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: numCount,
            itemBuilder: (context, index) {
              //print('${foodData[index].foodName}');
              bool reverse = widget.row == 2 ? index.isEven : index.isOdd;
              return Stack(
                children: [
                  Container(
                    margin: EdgeInsets.all(0),
                    padding: EdgeInsets.only(right: 10),
                    height: 240,
                    width: 200,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => food_detail(imgPath: foodData[index].foodImg.toString(),
                          price: foodData[index].foodPrice.toString(),
                          name: foodData[index].foodName.toString(),detail: foodData[index].foodDetail.toString(),index: index,Catagory: foodData[index].foodCategory.toString(),row: widget.row,)));
                      },
                      child: Card(
                        color: Theme.of(context).primaryColor,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 20),
                          child: Column(
                            children: [
                              Text(
                                '${foodData[index].foodName}',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ),
                              Spacer(),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Spacer(),
                                  Text(
                                    '${foodData[index].foodPrice} VND',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Spacer(),
                                  GestureDetector (
                                    onTap: () {
                                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => food_detail(imgPath: foodData[index].foodImg.toString(),
                                        price: foodData[index].foodPrice.toString(),
                                      name: foodData[index].foodName.toString(),detail: foodData[index].foodDetail.toString(),index: index,Catagory: foodData[index].foodCategory.toString(),row: widget.row,)));
                                    },
                                    child: Container(
                                      width: 50,
                                      height: 50,
                                      child: Card(
                                        child: Icon(Icons.add),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        elevation: 3,
                        margin: EdgeInsets.all(10),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(15),
                          bottomRight: Radius.circular(15),
                          topRight: Radius.circular(15),
                          topLeft: Radius.circular(15),
                        )),
                      ),
                    ),
                  ),
                  Positioned(
                    child: GestureDetector(
                        onTap: () {
                          setState(() {
                            addStringToSF() async {
                              SharedPreferences prefs = await SharedPreferences.getInstance();
                              prefs.setString('stringValue', "abc");
                            }
                          });
                          Navigator.of(context).push(MaterialPageRoute(builder: (context) => food_detail(imgPath: foodData[index].foodImg.toString(),
                            price: foodData[index].foodPrice.toString(),
                            name: foodData[index].foodName.toString(),detail: foodData[index].foodDetail.toString(),index: index,Catagory: foodData[index].foodCategory.toString(),row: widget.row,)));
                        },
                        child: Container(
                          height: 100,
                            child: Image.asset('${foodData[index].foodImg}', fit: BoxFit.cover, height: 100, width: 148,),
                           // child: Image.asset('images/hamberger_01.jpg'),
                        )),
                    top: 75,
                    left: 20,
                  ),
                ],
              );
            }),
      ),
    );
  }
}
