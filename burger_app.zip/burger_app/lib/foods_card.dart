import 'dart:convert';
import 'package:burger_app/Cart/CardModel.dart';
import 'package:burger_app/your_cart.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'Food/FoodModel.dart';
import 'Food/catalog_product.dart';
import 'bugger_fage.dart';
import 'data_sources/api_services.dart';

class NetworkRequest {
  static String IP = url;
  static String Url = "shop_food_api/api/foods/readFoods.php";
  static String GetCard = IP + Url;

  static List<Food> parseCate(String responseBody) {
    var list = json.decode(responseBody) as List<dynamic>;
    List<Food> foods = list.map((model) => Food.fromJson(model)).toList();
    return foods;
  }

  static Future<List<Food>> fetchCate({int page = 1}) async {
    final response = await http.get(Uri.parse(GetCard));
    if (response.statusCode == 200) {
      return compute(parseCate, response.body);
    } else if (response.statusCode == 404) {
      throw Exception("Not Found");
    } else {
      throw Exception("Can\'t get category");
    }
  }
}

class foodsCard extends StatefulWidget {
  @override
  _foodsCardsState createState() => _foodsCardsState();
}

class _foodsCardsState extends State<foodsCard> {
  List<Food> Fooddata = List.empty();
  @override
  void initState() {
    super.initState();
    NetworkRequest.fetchCate().then((value) {
      setState(() {
        Fooddata = value;
      });
    });
  }

  Widget build(BuildContext context) {
    // TODO: implement build

    return Scaffold(
      appBar: AppBar(
        title: Text("Catalog"),
      ),
      body: SafeArea(
        child: Column(
          children: [
            CatalogProduct(),
            Center(
                child: ElevatedButton(
                    onPressed: () {
                      Get.to(()=>CartScreen());
                    },
                    child: Text("Go to Cart"))),
          ],
        ),
      ),
    );
  }
}
