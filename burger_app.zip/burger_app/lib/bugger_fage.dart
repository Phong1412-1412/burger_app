import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
class BuggerFage extends StatefulWidget {
  static const tag = "bugger_fage";
  @override
  _BuggerFageState createState()=>  _BuggerFageState();

}

class _BuggerFageState extends State<BuggerFage> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(

      ),
    );
  }
}