import 'package:burger_app/Cart/Cart_Prodcut.dart';
import 'package:burger_app/Cart/Cart_total.dart';
import 'package:flutter/material.dart';

class CartScreen extends StatefulWidget {

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _CartScreenState();
  }

}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(title: Text("Your Cart"),
      ),
      body: Column(
        children: [
          CartProdcut(),
          CartTotal(),
        ],
      ),
    );
  }
}