import 'dart:convert';
import 'login_foodshop.dart';
import 'package:burger_app/login_foodshop.dart';
import 'package:burger_app/your_cart.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'User/UserModel.dart';
import 'data_sources/api_services.dart';
import 'header_login.dart';
import 'categories.dart';
import 'foods_list.dart';
import 'bugger_fage.dart';
import 'header_notlogin.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:get/get.dart';

class NetworkRequest {
  static String IP = url;
  static String ApiAdress = "shop_food_api/api/user_api/read_nguoidung.php";
  static String getUser = IP + ApiAdress;

  static List<userModel> parseCate(String responseBody) {
    var list = json.decode(responseBody) as List<dynamic>;
    List<userModel> userModels = list.map((model) => userModel.fromJson(model))
        .toList();
    return userModels;
  }

  static Future<List<userModel>> fetchCate({int page = 1}) async {
    final response = await http.get(Uri.parse(getUser));
    if (response.statusCode == 200) {
      return compute(parseCate, response.body);
    }
    else if (response.statusCode == 404) {
      throw Exception("Not Found");
    }
    else {
      throw Exception("Can\'t get category");
    }
  }
}

void main() {
  runApp(GetMaterialApp(home: MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key,}) : super(key: key);
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      theme: ThemeData(
        primaryColor: Colors.teal,
        cardColor: Colors.white,
          appBarTheme: AppBarTheme(
            color: Colors.teal,
            centerTitle: true,
          ),
          bottomAppBarColor: (Colors.teal),
          floatingActionButtonTheme: FloatingActionButtonThemeData(
            backgroundColor: Colors.teal,
          )),
      home: HambergerApp(),
      routes:{BuggerFage.tag: (_)=>BuggerFage(),},
      debugShowCheckedModeBanner: false,
    );
  }
}

class HambergerApp extends StatefulWidget {
   HambergerApp({Key? key}) : super(key: key);
  @override
  _HambergerAppSate createState() => _HambergerAppSate();
}

bool isLogin = true;

class _HambergerAppSate extends State<HambergerApp> {
  List<userModel> userData = List.empty();
  @override
  void initState() {
    super.initState();
    NetworkRequest.fetchCate().then((value) {
      setState(() {
        userData = value;
      });
    });
  }
  Widget build(BuildContext context) {

    // TODO: implement build
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            stretch: true,
            pinned: true,
            title: Text("Foods Shop"),
           // leading: IconButton(onPressed: () {}, icon: Icon(Icons.menu)),
            actions: [
              IconButton(onPressed: () {
               Get.to(()=>CartScreen());
              }, icon: Icon(Icons.shopping_cart),
              ),
            ],
          ),
          logInSuccess == true ?Header():Header_notLogin(),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(top: 20, left: 10, right: 10, bottom: 8),
              child: Center(
                child: SizedBox(
                    height: 200.0,
                    width: 350.0,
                    child: Carousel(
                      images: [
                        NetworkImage('https://intphcm.com/data/upload/banner-dep.jpg'),
                        NetworkImage('https://intphcm.com/data/upload/mau-banner-nha-hang.jpg'),
                        NetworkImage('https://i.pinimg.com/736x/3f/8e/48/3f8e48a0b20f4dc0671a8e5e8dd861a4.jpg'),
                        //ExactAssetImage("assets/images/LaunchImage.jpg")
                      ],
                      showIndicator: true,
                      borderRadius:true,
                      moveIndicatorFromBottom: 100.0,
                      noRadiusForIndicator: true,
                      overlayShadow: true,
                      overlayShadowColors: Colors.teal,
                      overlayShadowSize: 0.5,
                    )
                ),
              ),
            ),
          ),
          Categories(),
          FoodsList(1,"shop_food_api/api/foods/readFoods.php"),
          FoodsList(2,"shop_food_api/api/foods/readFoodDrink.php"),
        ],

      ),
      extendBody: true,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: Icon(Icons.home),
      ),
      bottomNavigationBar: ClipRect(
        child: Container(
          color: Colors.black38,
          child: BottomAppBar(
            shape: CircularNotchedRectangle(),
            child: Row(
              children: [
                Spacer(),
                IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.add_alert,
                    color: Colors.white,
                  ),
                ),
                Spacer(),

                Spacer(),
                IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.turned_in,
                    color: Colors.white,
                  ),
                ),
                Spacer(),
              ],
            ),
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children:  <Widget>[
            UserAccountsDrawerHeader(
              accountName: Text("Minh Nguyệt"),
              accountEmail: Text("MinhNguyet@gmail.com"),
              currentAccountPicture: CircleAvatar(
                backgroundColor:
                Theme.of(context).platform == TargetPlatform.iOS
                    ? Colors.blue
                    : Colors.white,
                child: Text("MN", style: TextStyle(fontSize: 30),)
              ),
            ),
            ListTile(
              leading: Icon(Icons.message),
              title: Text('Messages'),
            ),
            ListTile(
              leading: Icon(Icons.account_circle),
              title: Text('Profile'),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Settings'),
            ),

            logInSuccess == true ?
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Đăng xuất'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LoginFoodShop())
                );
              },
            ): ListTile(
              leading: Icon(Icons.logout),
              title: Text('Đăng Nhập'),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LoginFoodShop())
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
