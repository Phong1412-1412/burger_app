import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import './data_sources/api_services.dart';
import 'login_foodshop.dart';
import './User/UserModel.dart';

class NetworkRequest {
  static String IP = url;
  static String ApiAdress = "shop_food_api/api/user_api/read_nguoidung.php";
  static String getUser = IP + ApiAdress;

  static List<userModel> parseCate(String responseBody) {
    var list = json.decode(responseBody) as List<dynamic>;
    List<userModel> userModels = list.map((model) => userModel.fromJson(model))
        .toList();
    return userModels;
  }

  static Future<List<userModel>> fetchCate({int page = 1}) async {
    final response = await http.get(Uri.parse(getUser));
    if (response.statusCode == 200) {
      return compute(parseCate, response.body);
    }
    else if (response.statusCode == 404) {
      throw Exception("Not Found");
    }
    else {
      throw Exception("Can\'t get category");
    }
  }
}


class Header extends StatefulWidget {
  @override
  _HeaderState createState() => _HeaderState();
}

class _HeaderState extends State<Header> {
  List<userModel> userData = List.empty();
  @override
  void initState() {
    super.initState();
    NetworkRequest.fetchCate().then((dataFromServer) {
      setState(() {
        userData = dataFromServer;
      });
    });
  }
  Widget build(BuildContext context) {
    // TODO: implement build
   Size size = MediaQuery.of(context).size;
    return SliverList(
      delegate: SliverChildListDelegate(
        [
          Stack(
            children: [
              Column(
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 15),
                    height: size.height / 6,
                    decoration: const BoxDecoration(
                      color: Colors.teal,
                      borderRadius: BorderRadius.vertical(
                        bottom: Radius.circular(45),
                      ),
                      boxShadow: [
                        BoxShadow(
                          //offset:Offset(0, 0),
                          blurRadius: 20,
                        )
                      ],
                    ),
                    child: Column(
                      children: [
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.white70,
                              radius: 35,
                              child: CircleAvatar(
                                backgroundImage: AssetImage("images/avatar01.jpg"),
                                radius: 30,
                              ),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Column(
                              children: [
                                Text(
                                  "Admin",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: Colors.black54,
                                  ),
                                  child: Text(
                                    "GOLD MEMBER",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  ),
                                )
                              ],
                            ),
                            Spacer(),
                            Text(
                              "10.000.000 POINT",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20,),
                ],
              ),
              Positioned(
                bottom: 0,
                child: Container(
                  height: 50,
                  width: size.width,
                  child: Card(
                    margin: EdgeInsets.symmetric(horizontal: 35,),
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: TextFormField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "Bạn muốn mua gì?",
                        hintStyle: TextStyle(fontStyle: FontStyle.italic, color: Colors.black, fontSize: 20),
                        suffixIcon: Icon(Icons.search),
                        contentPadding: EdgeInsets.only(left: 20, top: 10),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
