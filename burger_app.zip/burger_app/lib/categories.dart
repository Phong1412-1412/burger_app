import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'data_sources/api_services.dart';

class Category {
  int? categoryID;
  String? categoryName;
  String? categoryIcon;

  Category({this.categoryID, this.categoryName, this.categoryIcon});

  Category.fromJson(Map<String, dynamic> json) {
    categoryID = json['Category_ID'];
    categoryName = json['Category_Name'];
    categoryIcon = json['Category_Icon'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Category_ID'] = this.categoryID;
    data['Category_Name'] = this.categoryName;
    data['Category_Icon'] = this.categoryIcon;
    return data;
  }
}

class Categories extends StatefulWidget {
  @override
  // ignore: no_logic_in_create_state
  State<StatefulWidget> createState() {
    return _CategoriesState();
  }
}

class NetworkRequest {
   static String IP = url;
   static String Url = "shop_food_api/api/category_api/read_category.php";
   static String GetCategory = IP + Url;

  static List<Category> parseCate(String responseBody) {
    var list = json.decode(responseBody) as List<dynamic>;
    List<Category> Categorys = list.map((model) => Category.fromJson(model)).toList();
    return Categorys;
  }

  static Future<List<Category>> fetchCate({int page = 1}) async {
    final response = await http.get(Uri.parse(GetCategory));
    if(response.statusCode == 200) {
      return compute(parseCate, response.body);
    }
    else if(response.statusCode == 404) {
      throw Exception("Not Found");
    }
    else {
      throw Exception("Can\'t get category");
    }
  }
}


class _CategoriesState extends State<Categories> {
  int currentSelectedItems = 0;
  List<Category> CateData = List.empty();
  @override
  void initState() {
  super.initState();
  NetworkRequest.fetchCate().then((dataFromServer) {
    setState(() {
      CateData = dataFromServer;
    });
  });
 }
  Widget build(BuildContext context) {
          return SliverToBoxAdapter(
            child: Container(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: CateData.length,
                itemBuilder: (context, index) => Stack(
                  children: [
                    Column(
                      children: [
                        Container(
                          margin:
                          EdgeInsets.only(left: index == 0 ? 20 : 0, right: 20),
                          height: 90,
                          width: 90,
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                currentSelectedItems = index;
                              });
                            },
                            child: Card(
                              color: index == currentSelectedItems
                                  ? Colors.black.withOpacity(0.7)
                                  : Colors.white,
                              child: Icon(

                                Icons.fastfood_sharp,
                                color: index == currentSelectedItems
                                    ? Colors.white
                                    : Colors.black.withOpacity(0.7),
                              ),
                              elevation: 3,
                              margin: EdgeInsets.all(10),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Positioned(
                      bottom: 0,
                      child: Container(
                        margin: EdgeInsets.only(left: index == 0 ? 20 : 0, right: 20),
                        width: 90,
                        child: Row(
                          children: [
                            Spacer(),
                            Text(
                              '${CateData[index].categoryName}',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Spacer(),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
  }
}
