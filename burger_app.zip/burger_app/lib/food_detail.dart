import 'dart:convert';

import 'package:burger_app/Food/catalog_product.dart';
import 'package:burger_app/main.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Cart/CardModel.dart';
import 'Cart/Cart_Controller.dart';
import 'Food/FoodModel.dart';
import 'data_sources/api_services.dart';
import 'frefs.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;



class NetworkRequest {
  static String IP = url;
  static String UrlFoods = "shop_food_api/api/foods/readFoods.php";
  static String UrlDrnik = "shop_food_api/api/foods/readFoodDrink.php";
  static String Url = "shop_food_api/api/foods/readFoods.php";
  static String GetCard = IP + Url;
  static List<Food> parseCate(String responseBody) {
    var list = json.decode(responseBody) as List<dynamic>;
    List<Food> foods = list.map((model) => Food.fromJson(model)).toList();
    return foods;
  }

  static Future<List<Food>> fetchCate({int page = 1}) async {
    final response = await http.get(Uri.parse(GetCard));
    if (response.statusCode == 200) {
      return compute(parseCate, response.body);
    } else if (response.statusCode == 404) {
      throw Exception("Not Found");
    } else {
      throw Exception("Can\'t get category");
    }
  }
}

List<Food> foodData = List.empty();

class food_detail extends StatefulWidget {
  @override
  String imgPath;
  String price;
  String name;
  String detail;
  String Catagory;
  int row;
  int index;
  food_detail({Key? key, required this.imgPath, required this.price,required this.name, required this.detail,required this.index, required this.Catagory, required this.row}) : super(key: key);
  food_detailState createState() => food_detailState(imgPath: imgPath, price: price, name: name, detail: detail, index: index, Category: Catagory, row: row);
}


class food_detailState extends State<food_detail> {
  final cartController = Get.put(CartController());
  String imgPath;
  String price;
  String name;
  String detail;
  String Category;
  int row;
  int index;
  food_detailState({Key? key, required this.imgPath, required this.price,required this.name, required this.detail, required this.index, required this.Category, required this.row});
  void initState() {
    super.initState();
    NetworkRequest.fetchCate().then((value) {
      setState(() {
        foodData = value;
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text(
        "FOOD DETAIL",
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
        ),
        backgroundColor: Colors.teal,
        leading: SizedBox(
          height: 40,
          width: 40,
          child: FlatButton(
            padding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
            color: Colors.white.withOpacity(0.5),
            onPressed: () {
              Navigator.pop(context);
            },
            child: Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Icon(Icons.arrow_back_ios),
            ),
          ),
        ),
      ),
      body: Column(
        children: <Widget>[
           Center(
            child: Container(
              margin: const EdgeInsets.all(10.0),
              child: ClipRect(
                /** Banner Widget **/
                child: Banner(
                  message: "20% off !!",
                  location: BannerLocation.topEnd,
                  color: Colors.red,
                  child: Container(
                    color: Colors.green[100],
                    //height: MediaQuery.of(context).size.width-30.0,
                    width: MediaQuery.of(context).size.width-30.0,
                    child: Padding(
                      padding: EdgeInsets.fromLTRB(10, 20, 10, 20),
                      child: Column(
                        children: <Widget>[
                          Text('${row}'),
                          Image.asset(imgPath, height: 200, width: 250,),
                          Text(
                            name,
                            style: TextStyle(
                                color: Colors.green,
                                fontSize: 40,
                                fontWeight: FontWeight.bold), //TextStyle
                          ),
                          SizedBox(
                            height: 5,
                          ), //SizedBox
                          Text(
                            detail,
                            style: TextStyle(
                                color: Colors.green,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                            ),
                            textAlign: TextAlign.justify,//TextStyle
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Container(
                                margin: EdgeInsets.only(top: 10),
                                width: 200,
                                height: 50,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15)
                                ),
                                child: RaisedButton(
                                  child: Text('ADD TO CARD',style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),),
                                  color: Colors.greenAccent[400],
                                  onPressed: () {
                                    //bug index
                                    cartController.addProduct(foodData[index]);
                                  },
                                ),
                              ),
                              Text(price+" VND",style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green),),//Text
                            ],
                          ),

                        ], //<Widget>[]
                      ), //Column
                    ), //Padding
                  ), //Container
                ), //Banner
              ), //ClipRect
            ), //container
          ), //Center
        ],
      ),
    );
  }
}
