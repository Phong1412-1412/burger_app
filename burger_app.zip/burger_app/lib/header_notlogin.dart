import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:burger_app/User/user_evens.dart';
import 'package:burger_app/User/userStates.dart';
import 'login_foodshop.dart';

class Header_notLogin extends StatefulWidget {
  _Header_notLoginState createState() => _Header_notLoginState();
}

Widget BuildLogin(BuildContext context) {
  return Container(
    padding: EdgeInsets.symmetric(vertical: 25),
    width: double.infinity,
    child: RaisedButton(
        elevation: 5,
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginFoodShop()));
        },
        padding: EdgeInsets.all(15),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        color: Colors.white,
        child: Text(
          "Login Account",
          style: TextStyle(
              color: Color(0xff5ac18e),
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
    ),
  );
}

class _Header_notLoginState extends State<Header_notLogin> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SliverList(
      delegate: SliverChildListDelegate([
        Stack(
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              width: MediaQuery.of(context).size.width,
              height: size.height / 5,
              decoration: const BoxDecoration(
                color: Colors.teal,
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(45),
                ),
                boxShadow: [
                  BoxShadow(
                    //offset:Offset(0, 0),
                    blurRadius: 20,
                  )
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "Vui lòng đăng nhập tài khoản",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 18),
                  ),
                 SizedBox(height: 10,),
                 BuildLogin(context),
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20,
        ),
      ]),
    );

  }
}
