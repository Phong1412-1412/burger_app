import 'dart:convert';
import 'package:burger_app/frefs.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../Cart/CardModel.dart';
import '../data_sources/api_services.dart';
import 'package:http/http.dart' as http;
import 'package:get/get.dart';
import '../Cart/Cart_Controller.dart';
import 'FoodModel.dart';

class NetworkRequest {
  static String IP = url;
  static String Url = "";
  static String GetFoods = IP + Url;

  GetAPI(String API) {
    Url = API;
    GetFoods = IP+Url;
  }

  static List<Food> parseFood(String responseBody) {
    var list = json.decode(responseBody) as List<dynamic>;
    List<Food> Foods = list.map((model) => Food.fromJson(model)).toList();
    return Foods;
  }

  static Future<List<Food>> fetchFood({int page = 1}) async {
    final response = await http.get(Uri.parse(GetFoods));
    if (response.statusCode == 200) {
      return compute(parseFood, response.body);
    } else if (response.statusCode == 404) {
      throw Exception("Not Found");
    } else {
      throw Exception("Can\'t get category");
    }
  }
}

List<Food> foodData = List.empty();

class CatalogProduct extends StatefulWidget {
  @override
  CatalogProductState createState() => CatalogProductState();
}

class CatalogProductState extends State<CatalogProduct> {
  @override
  void initState() {
    super.initState();
    NetworkRequest.fetchFood().then((value) {
      setState(() {
        foodData = value;
      });
    });
  }

  Widget build(BuildContext context) {
    // TODO: implement build
    return Flexible(
      child: ListView.builder(
        itemCount: foodData.length,
        itemBuilder: (context, int index) {
          return CatalogProductCart(
            index: index,
          );
        },
      ),
    );
  }
}

class CatalogProductCart extends StatefulWidget {
  final int index;
  CatalogProductCart({Key? key, required this.index}) : super(key: key);
  @override
  _CatalogProductCartState createState() =>
      _CatalogProductCartState(index: index);
}

class _CatalogProductCartState extends State<CatalogProductCart> {
  int index;
  final cartController = Get.put(CartController());
  _CatalogProductCartState({required this.index});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
      child: Row(
        children: [
          CircleAvatar(
            radius: 40,
            backgroundImage: AssetImage("${foodData[index].foodImg}"),
          ),
          SizedBox(
            width: 20,
          ),
          Expanded(
            child: Text(
              "${foodData[index].foodName}",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ),
          Expanded(
            child: Text(
              "${foodData[index].foodPrice}",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ),
          IconButton(onPressed: () {
            cartController.addProduct(foodData[index]);
          }, icon: Icon(Icons.add_circle))
        ],
      ),
    );
  }
}
