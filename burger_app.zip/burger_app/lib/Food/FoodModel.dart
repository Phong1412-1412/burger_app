class Food {
int? foodID;
String? foodName;
String? foodImg;
int? foodPrice;
int? foodCategory;
String? foodDetail;

Food(
    {this.foodID,
      this.foodName,
      this.foodImg,
      this.foodPrice,
      this.foodCategory,
      this.foodDetail});

Food.fromJson(Map<String, dynamic> json) {
foodID = json['Food_ID'];
foodName = json['Food_Name'];
foodImg = json['Food_Img'];
foodPrice = json['Food_Price'];
foodCategory = json['Food_Category'];
foodDetail = json['Food_Detail'];
}

Map<String, dynamic> toJson() {
  final Map<String, dynamic> data = new Map<String, dynamic>();
  data['Food_ID'] = this.foodID;
  data['Food_Name'] = this.foodName;
  data['Food_Img'] = this.foodImg;
  data['Food_Price'] = this.foodPrice;
  data['Food_Category'] = this.foodCategory;
  data['Food_Detail'] = this.foodDetail;
  return data;
}
}